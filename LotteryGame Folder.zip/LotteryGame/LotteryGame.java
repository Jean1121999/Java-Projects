

import java.util.Random;
import java.util.Scanner;

public class LotteryGame {
    //Initializing my instances
    private static final String ERROR = "INVALID ENTRY!";
    public int upperbound;
    private Random ran;

    public LotteryGame(){
    }

    /* Instructions */
    public void instructions(){
        System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n" +
                "                   INSTRUCTIONS\n" +
                "                   ------------\n" +
                "   The Lottery game consists of the user guessing four numbers\n" +
                "   The user gets points for guessing the numbers. Below are the\n" +
                "   grading scale\n" +
                "   0 Guess: 0 Point\"" +
                "   1 Guess: 5 Points\n" +
                "   2 Guesses: 100 Points\n" +
                "   3 Guesses: 2,000 Points\n" +
                "   4 Guesses: 1,000,000 Points");
    }

    /* Welcome Message */
    public void welcomeMessage(){
        System.out.println("\n\n\n\n\n\n\n\n\t\t\t\t\t\tWELCOME TO THE LOTTERY GAME!\n\n\n\n\n");
        System.out.print("\n\n\n     Please enter any letters or numbers and press ENTER to continue");
        Scanner scanner = new Scanner(System.in);
        String input = scanner.next();
        while (input != null){
            break;
        }
    }

    public void goodByeMessage(){
        System.out.println("Thanks for your time.");
    }

    public void playGame(){

        Scanner scanner = new Scanner(System.in);
        int[] userInput2 = new int[4];
        int countWin = 0;
        int countLoss = 0;
        ran = new Random();
        int[] random= new int[4];
        int i=0;
        int errorLimit =0;
        int n=1;

        for (i=0; i<4; i++){
            random[i] = ran.nextInt(9); // Setting the random[i] range from 0-9

            //Prompting the user to enter a random[i] number.
            System.out.print("\nAttempt Number "+(i+1)+"\n" +
                    "Enter a number between 0 and " + 9 + "\n" +
                    ": ");
            userInput2[i] = scanner.nextInt();

            //Ensuring that the user does not enter a number greater than 9
            while (userInput2[i] > 9){
                errorLimit+=1;
                System.out.println("\n"+ ERROR + " YOU HAVE " + (5-errorLimit) + " attempts left before the program closes".toUpperCase()); //Displaying the error message
                System.out.print("\nAttempt Number "+(i+1)+"\n" +
                        "Enter a number between 0 and " + 9 + "\n" +
                        ": ");
                userInput2[i] = scanner.nextInt();

                //Breaking out of the loop after the user either enters the correct entry or get past the Error limit
                if (errorLimit >= 4 | userInput2[i] < 10 ){
                   break;
                }
            }
            if (errorLimit >= 4){
                break;
            }
            //Checking the user entry against the computer
            else if (userInput2[i] != random[i]){
                countLoss+=1;
                System.out.println("Computer guessed: "+random[i]);
                System.out.println("You guessed: "+userInput2[i]);
            }
            else {
                countWin+=1;
                System.out.println("Computer guessed: "+random[i]);
                System.out.println("You guessed: "+userInput2[i]);
            }
        }


        //Displays a message after the user has past the error limit
        if (errorLimit >= 4){
            System.out.println("You have exceeded the amount of error.");
            goodByeMessage();
        }


        else {

            System.out.println("\n\n\n\n\n\t\t\t\t\t\t\tHere is your result:\n" +
                    "\t\t\t\t\t\t\t--------------------\n");
            String result = countWin == 0 ? "\t\t\t\t\t\t\tYou lost! You won 0 point" : countLoss == 0 ? "\t\t\t\t\t\t\tFantastic! You won 1,000,000 Points" :
                    countWin == 1 ? "\t\t\t\t\t\t\tYou can do better! You won 5 Points" : countWin == 2 ? "\t\t\t\t\t\t\tGood Job! You won 100 Points" : countWin == 3 ?
                            "\t\t\t\t\t\t\tImpressive! You won 2,000 Points" : "";

            System.out.println(result);
            System.out.println("\t\t\t\t\t\t\tWin: " + countWin + "\n" +
                    "\t\t\t\t\t\t\tLoss: " + countLoss);

            for (i = 0; i < 4; i++) {
                System.out.println("\n\t\t\t\t\t\t\tAttempt Number " + (i + 1) + "\n" +
                        "\t\t\t\t\t\t\tComputer Guessed: " + random[i] + "\n" +
                        "\t\t\t\t\t\t\tYou guessed: " + userInput2[i] + "\n" +
                        "\t\t\t\t\t\t\t-------------------");
            }
        }

    }
}
