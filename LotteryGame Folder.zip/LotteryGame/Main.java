import java.util.Scanner;

//Author: Jean Aime Lukuka
//Program Name: LotteryGame.java
//
//Description: The lottery game consists of the user guessing a number
//             against the computer.
//
//Date: 1/23/2021
//Date: Updated 1/25/2021 

public class Main extends LotteryGame {

    private static String ERROR = "Invalid Entry";
    public static void main(String[] args) {

        /* Main Script */
        LotteryGame lotteryGame = new LotteryGame();
        System.out.println("LOTTERY GAME");
        lotteryGame.welcomeMessage(); //Welcome message
        lotteryGame.instructions(); // Instructions



        Scanner scanner = new Scanner(System.in);
        String userInput;
        System.out.print("\n\n\n\nDo you which to continue?\n" +
                "Enter y[yes] or n [No]"); // Ask the user to either continue, quit or ask questions
        userInput = scanner.next();
        String user = userInput.toLowerCase();

        //Ensuring that the user input is valid
        boolean input = user.equals("y") | user.equals("n");

        //Prompting the user the same message in case he enters an invalid entry
        while (!input){
            System.out.print("\n\n\n\n"+ERROR+"\nDo you which to continue?\n" +
                    "Enter y[yes] or n [No]"); // Ask the user to either continue or quit
            user = scanner.next();
            boolean input2 = user.equals("y") | user.equals("n");
            //breaks if the user enter a valid entry [y/n]
            if (input2){
                break;
            }
        };

        //Playing the game after the user agrees to play by entering "y" or "Y"
        if (user.equals("y")){
            lotteryGame.playGame();

        }

        //Quiting the game after the user enters "n" or "N"
        else if (user.equals("n")){
            lotteryGame.goodByeMessage();
        }


    }
}




